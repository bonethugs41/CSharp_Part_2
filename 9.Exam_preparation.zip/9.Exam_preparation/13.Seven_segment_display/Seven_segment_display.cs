﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13.Seven_segment_display
{
    class SevenSegmentDisplay
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

        }
    }
}
